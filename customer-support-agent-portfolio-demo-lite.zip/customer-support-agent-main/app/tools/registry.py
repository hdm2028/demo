from copy import deepcopy
from dataclasses import asdict, dataclass
from typing import Any

from app.core.schemas import ToolResult
from app.tools.human_review import create_manual_review, transfer_to_human
from app.tools.order import order_lookup
from app.tools.policy import policy_search
from app.tools.refund import refund_apply
from app.tools.risk import risk_check
from app.tools.ticket import create_ticket


FUNCTION_TOOL_SPECS = [
    {
        "type": "function",
        "function": {
            "name": "order_lookup",
            "description": "根据订单号查询订单状态、商品、物流和售后相关字段。",
            "parameters": {
                "type": "object",
                "properties": {
                    "order_id": {
                        "type": "string",
                        "description": "用户提供的订单号。",
                    }
                },
                "required": ["order_id"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "policy_search",
            "description": "检索售后政策知识库，返回带 citation 的证据片段。",
            "parameters": {
                "type": "object",
                "properties": {
                    "semantic_query": {
                        "type": "string",
                        "description": "保留自然语言语义并附加结构化事实的向量检索问题。",
                    },
                    "lexical_query": {
                        "type": "string",
                        "description": "由上游语义标签确定性扩展的 BM25 检索问题。",
                    },
                    "top_k": {
                        "type": "integer",
                        "description": "返回的政策证据数量。",
                        "default": 2,
                    },
                },
                "required": ["semantic_query", "lexical_query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "risk_check",
            "description": "调用风控 Agent 检测高频退款、异常账号、恶意投诉和虚假描述。",
            "parameters": {
                "type": "object",
                "properties": {
                    "order_id": {
                        "type": "string",
                        "description": "关联订单号。",
                    },
                    "user_request": {
                        "type": "string",
                        "description": "用户原始售后诉求。",
                    },
                },
                "required": ["order_id", "user_request"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "refund_apply",
            "description": "创建退款申请并投递 MQ，由退款处理服务异步更新订单状态。",
            "parameters": {
                "type": "object",
                "properties": {
                    "order_id": {
                        "type": "string",
                        "description": "关联订单号。",
                    },
                    "user_request": {
                        "type": "string",
                        "description": "用户原始退款诉求。",
                    },
                    "risk_assessment": {
                        "type": "object",
                        "description": "风控 Agent 输出的风险评估。",
                    },
                },
                "required": ["order_id", "user_request"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "create_manual_review",
            "description": "创建人工审核单，处理大额退款、异常账号和投诉升级等高风险售后动作。",
            "parameters": {
                "type": "object",
                "properties": {
                    "order_id": {
                        "type": "string",
                        "description": "关联订单号。",
                    },
                    "review_type": {
                        "type": "string",
                        "description": "审核类型，如 refund、complaint、risk_control。",
                    },
                    "risk_level": {
                        "type": "string",
                        "description": "风控等级。",
                    },
                    "risk_flags": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "触发的风险原因。",
                    },
                    "user_request": {
                        "type": "string",
                        "description": "用户原始诉求。",
                    },
                    "related_id": {
                        "type": "string",
                        "description": "关联退款申请号或工单号。",
                    },
                },
                "required": ["review_type", "risk_level", "risk_flags", "user_request"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "create_ticket",
            "description": "创建待人工审核的售后工单草稿，不执行真实退款、赔付、取消或改地址。",
            "parameters": {
                "type": "object",
                "properties": {
                    "order_id": {
                        "type": "string",
                        "description": "关联订单号。",
                    },
                    "issue_type": {
                        "type": "string",
                        "description": "售后问题类型。",
                    },
                    "user_request": {
                        "type": "string",
                        "description": "用户原始诉求。",
                    },
                    "priority": {
                        "type": "string",
                        "description": "工单优先级。",
                        "default": "normal",
                    },
                },
                "required": ["order_id", "issue_type", "user_request"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "transfer_to_human",
            "description": "生成转人工交接单，用于用户明确要求人工或高风险售后场景。",
            "parameters": {
                "type": "object",
                "properties": {
                    "reason": {
                        "type": "string",
                        "description": "转人工原因。",
                    },
                    "user_request": {
                        "type": "string",
                        "description": "用户原始诉求。",
                    },
                    "priority": {
                        "type": "string",
                        "description": "交接优先级。",
                        "default": "normal",
                    },
                },
                "required": ["reason", "user_request"],
            },
        },
    },
]


TOOL_HANDLERS = {
    "order_lookup": order_lookup,
    "policy_search": policy_search,
    "risk_check": risk_check,
    "refund_apply": refund_apply,
    "create_manual_review": create_manual_review,
    "create_ticket": create_ticket,
    "transfer_to_human": transfer_to_human,
}

AGENT_TOOL_PERMISSIONS = {
    "customer_agent": {"policy_search"},
    "after_sales_agent": {
        "order_lookup",
        "refund_apply",
        "create_manual_review",
        "create_ticket",
        "transfer_to_human",
    },
    "risk_agent": {"risk_check"},
}


READ_ONLY = "READ_ONLY"
SIDE_EFFECT = "SIDE_EFFECT"


@dataclass(frozen=True)
class ToolRuntimePolicy:
    timeout_seconds: float
    max_attempts: int
    retry_on: tuple[str, ...]
    side_effect_class: str
    idempotent: bool
    fallback_action: str
    backoff_seconds: float = 0.1
    fail_closed: bool = False
    recovery_action: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


TOOL_RUNTIME_POLICIES = {
    "order_lookup": ToolRuntimePolicy(
        timeout_seconds=3.0,
        max_attempts=2,
        retry_on=("ToolTimeout", "ToolTransientError"),
        side_effect_class=READ_ONLY,
        idempotent=True,
        fallback_action="ask_user_to_retry_or_handoff",
    ),
    "policy_search": ToolRuntimePolicy(
        timeout_seconds=8.0,
        max_attempts=2,
        retry_on=("ToolTimeout", "ToolTransientError"),
        side_effect_class=READ_ONLY,
        idempotent=True,
        fallback_action="handoff_to_human",
    ),
    "risk_check": ToolRuntimePolicy(
        timeout_seconds=4.0,
        max_attempts=2,
        retry_on=("ToolTimeout", "ToolTransientError"),
        side_effect_class=READ_ONLY,
        idempotent=True,
        fallback_action="create_manual_review_or_handoff_to_human",
        fail_closed=True,
    ),
    "refund_apply": ToolRuntimePolicy(
        timeout_seconds=8.0,
        max_attempts=1,
        retry_on=(),
        side_effect_class=SIDE_EFFECT,
        idempotent=True,
        fallback_action="recover_refund_status_or_handoff",
        recovery_action="check_order_idempotency_state_before_any_replay",
    ),
    "create_manual_review": ToolRuntimePolicy(
        timeout_seconds=5.0,
        max_attempts=1,
        retry_on=(),
        side_effect_class=SIDE_EFFECT,
        idempotent=False,
        fallback_action="manual_queue",
    ),
    "create_ticket": ToolRuntimePolicy(
        timeout_seconds=5.0,
        max_attempts=1,
        retry_on=(),
        side_effect_class=SIDE_EFFECT,
        idempotent=False,
        fallback_action="handoff_to_human",
    ),
    "transfer_to_human": ToolRuntimePolicy(
        timeout_seconds=5.0,
        max_attempts=1,
        retry_on=(),
        side_effect_class=SIDE_EFFECT,
        idempotent=False,
        fallback_action="manual_queue",
    ),
}


def get_tool_runtime_policy(tool_name: str) -> ToolRuntimePolicy | None:
    return TOOL_RUNTIME_POLICIES.get(tool_name)


def get_function_tool_specs() -> list[dict[str, Any]]:
    """返回 Function Calling 风格的工具定义，供 API、评测和前端展示。"""

    return deepcopy(FUNCTION_TOOL_SPECS)


def get_required_arguments(tool_name: str) -> list[str]:
    """读取某个工具 schema 中声明的必填参数。"""

    for spec in FUNCTION_TOOL_SPECS:
        function = spec["function"]

        if function["name"] == tool_name:
            return list(function["parameters"].get("required", []))

    return []


def validate_tool_arguments(tool_name: str, arguments: dict[str, Any]) -> tuple[bool, list[str]]:
    """执行工具前做最小参数校验，避免模型或路由层越权乱调。"""

    if tool_name not in TOOL_HANDLERS:
        return False, [f"未知工具：{tool_name}"]

    missing = [
        name for name in get_required_arguments(tool_name)
        if arguments.get(name) in (None, "")
    ]

    if missing:
        return False, [f"缺少必要参数：{', '.join(missing)}"]

    return True, []


def can_agent_use_tool(agent_key: str, tool_name: str) -> bool:
    return tool_name in AGENT_TOOL_PERMISSIONS.get(agent_key, set())


def execute_registered_tool(tool_name: str, arguments: dict[str, Any]) -> ToolResult:
    valid, errors = validate_tool_arguments(tool_name, arguments)

    if not valid:
        return ToolResult(
            tool_name=tool_name,
            success=False,
            result={
                "error_type": "InvalidToolArguments",
                "errors": errors,
                "fallback_action": "ask_user_or_handoff_to_human",
            },
        )

    handler = TOOL_HANDLERS[tool_name]
    result = handler(**arguments)

    if isinstance(result, ToolResult):
        return result

    return ToolResult(tool_name=tool_name, success=True, result=result)
